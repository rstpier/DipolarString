# Dipolar String Model — V2.9.1 Zenodo edition

Author: R. St-Pierre  
Date: 31 August 2026  
Concept DOI: 10.5281/zenodo.21196098

## Recommended deposit files

- `DS_model_V2_9_1_Zenodo.pdf` — compiled publication manuscript (67 pages).
- `DS_model_V2_9_1_Zenodo.tex` — complete LaTeX source.
- `DS_model_V2_9_1_Zenodo_source.zip` — reproducible source bundle, including figures and the LRD regeneration script.
- `ZENODO_README_CHANGELOG.md` — deposit notes and revision history.

## Compilation

Requirements: a standard TeX Live installation with `latexmk`, `tikz`, `tikz-3dplot`, `mathtools`, `booktabs`, `caption`, `hyperref`, and Latin Modern fonts.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error DS_model_V2_9_1_Zenodo.tex
```

The corrected Little Red Dot figure can be regenerated before compilation with:

```bash
python regenerate_lrd_figure.py
```

The script requires NumPy, SciPy, and Matplotlib. It integrates the dimensionless A8-consistent equilibrium equations printed in the manuscript and normalizes their first maximum to the stated critical mass.

## V2.9.1 scientific changes

1. The complete V2.9 manuscript and all appendices are restored; the superseded 29-page reduction is excluded.
2. The low-impedance entanglement corridor, synchronization-speed formula, Bell-derived impedance bounds, and measurement-induced PLL-unlock mechanism are withdrawn.
3. Anti-phase operation is retained only as a conditional differential normal mode, not as a derived pair-creation or entanglement mechanism.
4. The telegrapher action now gives the Euclidean compact-phase normalization explicitly. Under the simultaneous assumptions (q=e/3), (Z_s=Z_0), three equivalent strings, and winding (1/3), the logarithmic phase-slip coefficient is (3/(4\alpha)).
5. That coefficient is explicitly distinguished from a complete instanton action. Fractional monodromy, core and screening scales, and a charged order-parameter sector remain missing.
6. The manuscript now states the second missing bridge: no equation derives a relation between instanton fugacity and Newton's constant. The proposed relation for (G) remains an exploratory conjecture.
7. The LRD mass-function figure is regenerated on the A8-consistent branch: (log_{10}M_{\rm crit}=6.11), median 6.02, 10th percentile 5.49, and 86% in the registered half-decade window under the log-uniform central-density prior.
8. The epistemological status table, abstract, introduction, open-problem inventory, and document history are synchronized with these changes.

## Suggested Zenodo description

This record contains the complete V2.9.1 publication edition of the Dipolar String Model, a speculative transmission-line model of a structured electromagnetic vacuum. The manuscript distinguishes derived, calibrated, postulated, withdrawn, and conditionally derived claims. This edition restores the full 67-page manuscript, withdraws the unsupported low-impedance entanglement corridor, and reformulates the proposed (G) relation: the coefficient (3/(4\alpha)) follows only conditionally as the logarithmic coefficient of a three-string fractional phase slip, while the core/scale contribution and the mapping from phase-slip fugacity to gravity remain unproved. The corrected substrate-star mass-function figure and its regeneration script are included.

## Suggested keywords

Dipolar strings; vacuum impedance; transmission-line electrodynamics; analogue gravity; substrate stars; emergent spacetime; phase slips; Little Red Dots; speculative physics.

## Deposit checks

- Confirm the author name, affiliation, contact address, and ORCID in Zenodo metadata.
- Select and declare a license; none is inferred by this package.
- Verify that every cited code file promised in the Data Availability section is attached to the same record or revise that statement before publication.
- Preserve the existing concept DOI and create a new version DOI for V2.9.1.
- Do not replace the registered historical prediction record; link this revision as a new version and describe the changed LRD figure transparently.
