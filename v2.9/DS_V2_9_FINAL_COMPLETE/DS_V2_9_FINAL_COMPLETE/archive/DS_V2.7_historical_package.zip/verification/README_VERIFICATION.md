# Verification manifest — CD/DS V2.7

## Usage
```
python3 verify_all.py          # full, 40 tests (~20 s, includes the uniqueness scan)
python3 verify_all.py --fast   # 34 tests, skips the uniqueness + hydro scans (~2 s)
```
Output: `[PASS/FAIL] claim (paper section) detail` table, return code 0 if all green.
Dependencies: numpy, scipy, sympy.

## Coverage (40 tests)

| Block | Sections | Claims verified |
|---|---|---|
| Geometry/impedance | S5.1–5.2, S12 | R3, l1, Ze=0.730 Z0 (275 Ohm), robustness x/div sqrt5, D/r=2cosh pi, Gamma_pole=1/3, E1=1.53 MeV, P=91 MW, F=607 mN, u0=4.6e23, alpha=e^2 Z0/2h, 9pi/2alpha=1937 |
| Theorem 4 (properties) | S7.3–7.5 | Entries {0,±1/2}, S_ii=0, no straight-through, S^T S=S^2=I, charge conservation (C2), flux conservation (C3), O_h invariance (inversion + 3 mirrors), Bloch dispersion omega/k=0.5 isotropic <1e-6 over 50 directions, 2 transverse pol., omega=0 mode (Gauss), 6 cutoff modes, orthogonality lemma |
| Theorem 4 (uniqueness scan) | S7.3–7.5 | C1: cubic equivariance reduces 144->8 orbits; C2+C3: charge/DQD + flux/axis -> 4 free; C4: S^T S=I -> finite branch set; C5: an isotropic branch exists **and** every isotropic C1–C4 solution is a Johns node {0,±1/2}, S_ii=0; the author's explicit SCN is recovered by the scan (in the C1 family, lossless, isotropic) |
| Gravitational sector | S8, S11 | Theorem 3 identity (null symbolic residual), conformal identity g_iso=e^chi g, Newton limit of the static geodesic, gamma=beta=1, 2PN deviations Dg00=-U^3/6 and Dgij=+U^2/2, null wave residual of the Heaviside ellipsoid, photon sphere r_ph=rs |
| Substrate stars | S9 | Mcrit=1.616e6 Msun at uc/u0~14, rs/R=1.217, scale b=c0^4/(16G sqrt(pi G u0)), scaling ∝l1^2 (exact) |
| LRD prediction | S15.1 | log Mcrit=6.21, median 6.10, 10% quantile ≈5.32*, f½=0.805 numeric + analytic Eq. 61 |
| Bell corridor | S10.2 | Zmin<28 mOhm, delta=D−2r≈5.4e-22 m |

*The 10% quantile comes out at 5.36 on this grid (paper: 5.32) — sensitive to the
branch resolution near uc->1; deviation <0.05 dex, no effect on f½ or the median.

## What this manifest does NOT verify (honest limits)
1. **The formulation**: each test checks that the consequences follow from the published
   equations — not that those equations describe nature. An ill-posed problem yields a
   green manifest. Safeguards: fresh adversarial AI instance, human third party, JWST data.
2. **The Postulated/Calibrated items**: A7, A8, E=hc0/l, sqrt(r0/r), lcell≈l1, NDS indices —
   untestable by construction; their status is declared in the paper (S13).

Note (since V2.5): the Theorem 4 uniqueness scan — previously in the separate script
`scn_from_dqd.py` (lost) — is now **integrated** into `verify_all.py` (block "Theorem 4
UNIQUENESS SCAN"). Independent rewrite: it reconstructs the result from the same
C1–C5 constraints, not a byte-for-byte copy of the archived file. A dedicated test
verifies that the author's explicit SCN is the member selected by the scan.

## Author's role (validation protocol without GR expertise)
1. Run it, confirm 40/40 and return code 0.
2. Traceability audit: every "Derived" item in S13 of the paper has a line here or
   in the original supplementary package. No script = declassification.
3. Engineer's sanity checks: dimensions, limits (Z->Z0 => Newton; v->0 => gamma->1),
   orders of magnitude — already encoded in several tests.
