# Licensing — Dipolar Strings (CD/DS) V2.7 package

**Manuscript and figures** (`DS_model_V2_7_final.pdf`, `.tex`, `figures/`)
Creative Commons Attribution 4.0 International (CC BY 4.0).
Full text: https://creativecommons.org/licenses/by/4.0/legalcode
This matches the licence of the Zenodo deposit of V2.6 (record 21434867).

**Code** (`scripts/`, `verification/`)
MIT License.

Copyright (c) 2026 R. St-Pierre

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

**Attribution.** Cite the Zenodo concept DOI 10.5281/zenodo.21196098 and the version DOI of
the V2.7 record.
