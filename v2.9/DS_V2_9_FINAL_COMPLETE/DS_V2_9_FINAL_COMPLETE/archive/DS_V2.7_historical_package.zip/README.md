# Dipolar Strings (CD/DS) — V2.7 reproducible package

Contents:
- `DS_model_V2_7_final.pdf` / `.tex` — manuscript (54 pp.), compiles with pdfLaTeX, no undefined references.
- `scripts/` — figure generation, gravitational-sector checks, and `p2_master.py` (all results of the
  breather appendix, Appendix D).
- `verification/` — `verify_all.py` (40 symbolic/numerical tests), README, MANIFEST, rerun logs.
- `figures/` — figures used by the manuscript.
- `requirements.txt` — frozen environment of the 2026-07-23 rerun (Python 3.12.3).
- `LICENSE.md` — CC BY 4.0 (manuscript, figures), MIT (code).

Reproduce:
```
pip install -r requirements.txt
cd verification && python3 verify_all.py        # expected: 40/40 PASS, exit 0
python3 scripts/p2_master.py rest               # breather appendix, first table
```
`p2_master.py all` includes h = 0.25 runs and takes several hours.

Status: exploratory working paper, no human peer review. See the Acknowledgments and
Methodological Disclosure section of the manuscript.
