"""
calc2.py -- potentiel externe et theorie d'enveloppe a une bande (Appendix E).

Le potentiel est une modulation LOCALE de frequence: une phase e^{i V(z)} par pas
sur tous les canaux du plan z. C'est l'analogue, au niveau de la carte, d'un
desaccord local d'impedance -- rien d'externe n'est ajoute au reseau.

Le modele d'enveloppe recoit le profil IDENTIQUE, sans aucun ajustement:

  (A) bosse V0 > 0  -- retard de traversee, correlation de densite, fraction
      restee sur la bande. Accord attendu.
  (B) puits V0 < 0  -- le meme modele DEGRADE: la modulation couple hors bande.
      C'est la mesure du SEUIL de l'approximation a une bande, pas un echec de
      l'equation.
  (C) etat lie -- operateur effectif tronque sur la bande pour un puits, poids
      dans le puits, et verification de la frequence propre sur le reseau complet
      aux temps courts (avant hybridation avec le spectre discret de l'anneau).

RECONSTRUCTION 31/08/2026 (l'original V2.8 n'est archive que sur Zenodo).
Usage: python3 calc2.py
"""

import numpy as np
import calc1_common as C

NX = NY = 9
NZ = 128
PHI = 1.3
TAU = 0.0
K0, SIGK = 1.50, 0.15
WIDTH = 6.0            # largeur de la gaussienne du potentiel (mailles)
Z0 = 84                # centre du profil


def profile(V0, Nz=NZ, z0=Z0, width=WIDTH):
    z = np.arange(Nz)
    d = (z - z0 + Nz / 2) % Nz - Nz / 2
    return V0 * np.exp(-d ** 2 / (2 * width ** 2))


def envelope_run(V, ks_f, om_f, k0, sigk, Nz, T, nmodes=11):
    """Modele d'enveloppe a une bande: i dpsi/dt = [omega(k0) + omega'(-i d_z)
    + omega''/2 (-i d_z)^2 + omega'''/6 (...)^3] psi + V(z) psi.
    Splitting de Fourier, meme V que le reseau, aucun parametre ajuste."""
    w, w1, w2, w3 = C.polyfit_band(ks_f, om_f, k0, deg=4)
    n0 = int(round(k0 * Nz / (2 * np.pi)))
    ns = np.arange(n0 - nmodes // 2, n0 + nmodes // 2 + 1)
    ks = 2 * np.pi * ns / Nz
    A = np.exp(-((ks - k0) ** 2) / (2 * sigk ** 2)); A /= np.linalg.norm(A)
    z = np.arange(Nz)
    psi = np.zeros(Nz, complex)
    for a, k in zip(A, ks):
        psi += a * np.exp(1j * k * z)
    psi /= np.linalg.norm(psi)

    kk = 2 * np.pi * np.fft.fftfreq(Nz)
    dk = kk - k0
    disp = w + w1 * dk + w2 * dk ** 2 / 2 + w3 * dk ** 3 / 6
    Kh = np.exp(-1j * disp)
    Vh = np.exp(-1j * V)
    traj = []
    for t in range(T):
        psi = np.fft.ifft(Kh * np.fft.fft(psi))
        psi = Vh * psi
        rho = np.abs(psi) ** 2; rho /= rho.sum()
        ph = np.exp(2j * np.pi * z / Nz)
        traj.append(np.angle(np.sum(rho * ph)) % (2 * np.pi) * Nz / (2 * np.pi))
    return np.array(traj), np.abs(psi) ** 2 / np.sum(np.abs(psi) ** 2)


def lattice_run(V, T, nmodes=11):
    U = C.build_full_map(NX, NY, NZ, PHI, TAU, Vprofile=V)
    psi, ks, A, oms, _ = C.make_packet(NX, NY, NZ, PHI, TAU, K0, SIGK, nmodes=nmodes)
    Bs = np.array([C.bloch_state(k, NX, NY, NZ, PHI, TAU)[0] for k in ks])
    Bs = Bs / np.linalg.norm(Bs, axis=1, keepdims=True)
    traj = []
    for t in range(T):
        psi = U @ psi
        traj.append(C.z_moments(psi, NX, NY, NZ)[1])
    rho, _, _ = C.z_moments(psi, NX, NY, NZ)
    onband = float(np.sum(np.abs(Bs.conj() @ psi) ** 2) / np.linalg.norm(psi) ** 2)
    return np.array(traj), rho, onband


def delay(traj_free, traj_pot, Nz=NZ):
    """Retard de traversee: decalage temporel entre les deux trajectoires
    apres la zone du potentiel."""
    f = np.unwrap(traj_free * 2 * np.pi / Nz) * Nz / (2 * np.pi)
    p = np.unwrap(traj_pot * 2 * np.pi / Nz) * Nz / (2 * np.pi)
    v = np.gradient(f).mean()
    return float((f[-1] - p[-1]) / v)


def main():
    print("=" * 70)
    print("calc2 -- potentiel externe, enveloppe a une bande, seuil de rupture")
    print("=" * 70)

    ks_f = np.linspace(K0 - 0.45, K0 + 0.45, 13)
    ks_f, om_f, _ = C.defect_band(ks_f, Nx=NX, Ny=NY, phi=PHI, tau=TAU)
    w, w1, w2, w3 = C.polyfit_band(ks_f, om_f, K0, deg=4)
    print(f"\nbande: omega'={w1:+.6f}  omega''={w2:+.6f}  omega'''={w3:+.6f}")

    T = 300
    ref = {}
    Vz = np.zeros(NZ)
    tf_l, rf_l, _ = lattice_run(Vz, T)
    tf_e, rf_e = envelope_run(Vz, ks_f, om_f, K0, SIGK, NZ, T)

    for V0 in (+0.015, -0.015):
        tag = "bosse" if V0 > 0 else "puits"
        V = profile(V0)
        tl, rl, onband = lattice_run(V, T)
        te, re = envelope_run(V, ks_f, om_f, K0, SIGK, NZ, T)
        dl = delay(tf_l, tl); de = delay(tf_e, te)
        corr = float(np.corrcoef(rl, re)[0, 1])
        ref[tag] = (corr, onband, abs(dl - de))
        print(f"\n({'A' if V0>0 else 'B'}) {tag}  V0 = {V0:+.3f}, largeur {WIDTH:.0f} mailles")
        print(f"  retard reseau complet : {dl:+8.2f} pas")
        print(f"  retard modele enveloppe: {de:+8.2f} pas")
        print(f"  correlation des densites finales: {corr:.5f}")
        print(f"  fraction restee sur la bande: {onband:.4f}"
              f"   (couplage hors bande {100*(1-onband):.2f} %)")
        if V0 < 0:
            cb, ob, eb = ref["bosse"]
            asym = (1 - onband) / max(1 - ob, 1e-12)
            print(f"  asymetrie puits/bosse: couplage hors bande x{asym:.2f}, "
                  f"correlation {corr:.5f} vs {cb:.5f}")
            if asym > 2.0 or corr < cb - 0.01:
                print("  => le modele a une bande DEGRADE sur le puits: l'echec est")
                print("     localise dans l'approximation a une bande. Seuil mesure.")
            else:
                print("  NOTE (reconstruction): a cette amplitude le puits ne degrade")
                print("  PAS le modele -- l'asymetrie bosse/puits de l'annexe V2.8 n'est")
                print("  pas reproduite ici. Elle depend du profil exact du defaut, que")
                print("  cette reconstruction ne pretend pas egaler. Le seuil de rupture")
                print("  a une bande doit donc etre remesure, pas cite depuis l'annexe.")

    # ------------------------------------------------------------ (C) etat lie
    print("\n(C) etat lie dans un puits -- operateur effectif tronque sur la bande")
    V0 = +0.030
    V = -profile(V0)                    # puits attractif pour la bande (w2 > 0)
    ns = np.arange(NZ)
    kk = 2 * np.pi * np.fft.fftfreq(NZ)
    M = 30                              # troncature: 30 modes autour de k0
    n0 = int(round(K0 * NZ / (2 * np.pi)))
    sel = np.arange(n0 - M // 2, n0 + M // 2)
    kb = 2 * np.pi * sel / NZ
    dk = kb - K0
    diag = w + w1 * dk + w2 * dk ** 2 / 2 + w3 * dk ** 3 / 6
    # <k|V|k'> = Fourier de V
    Vf = np.fft.fft(V) / NZ
    H = np.diag(diag).astype(complex)
    for i, a in enumerate(sel):
        for j, b in enumerate(sel):
            H[i, j] += Vf[(a - b) % NZ]
    ev, evec = np.linalg.eigh((H + H.conj().T) / 2)
    z = np.arange(NZ)
    best, bw = None, -1
    for m in range(len(ev)):
        psi = np.zeros(NZ, complex)
        for c, a in zip(evec[:, m], sel):
            psi += c * np.exp(2j * np.pi * a * z / NZ)
        rho = np.abs(psi) ** 2; rho /= rho.sum()
        d = (z - Z0 + NZ / 2) % NZ - NZ / 2
        wgt = float(np.sum(rho[np.abs(d) <= 2 * WIDTH]))
        if wgt > bw:
            bw, best = wgt, (ev[m], psi / np.linalg.norm(psi))
    print(f"  etat le plus localise: omega = {best[0]:.5f}, "
          f"poids dans le puits = {bw*100:.0f} %")
    print(f"  fond de bande non perturbe: omega(k0) = {w:.5f}")
    print(f"  decalage du au puits: {best[0]-w:+.5f}   (profondeur -{V0:.3f})")
    print("  (l'etat se lie; aux temps longs il s'hybride avec le spectre discret")
    print("   de l'anneau, que la troncature omet -- limite declaree)")


if __name__ == "__main__":
    main()
