"""
calc1.py -- enveloppe libre du defaut tresse (Appendix E, tests 1 a 3).

Trois mesures contre la carte COMPLETE du reseau (aucun ajustement):
  (i)   variance de position: loi dispersive exacte sigma^2(t) = sigma0^2 + t^2 Var_w(omega')
        contre sa troncature quadratique (Schrodinger); l'ecart est impute a omega'''.
  (ii)  transport modal: |A_k| constant, arg A_k = omega_k t.
  (iii) interference de deux paquets: le terme croise exact contre la prediction
        d'enveloppe complexe.

RECONSTRUCTION 31/08/2026 (l'original V2.8 n'est que sur Zenodo).
Usage: python3 calc1.py
"""

import numpy as np
import calc1_common as C

NX = NY = 9
NZ = 128
PHI = 1.3
TAU = 0.0              # calc1: defaut droit (le tressage est teste dans calc3)
K0, SIGK = 1.5, 0.15
T = 480


def band_derivatives(k0=K0, span=0.45, npts=13):
    ks = np.linspace(k0 - span, k0 + span, npts)
    ks, om, _ = C.defect_band(ks, Nx=NX, Ny=NY, phi=PHI, tau=TAU)
    return ks, om, C.polyfit_band(ks, om, k0, deg=4)


def main():
    print("=" * 68)
    print("calc1 -- enveloppe libre sur le reseau de Johns a defaut tresse")
    print(f"maillage {NX}x{NY}x{NZ}, 12 ports/cellule -> {NX*NY*NZ*12} amplitudes")
    print("=" * 68)

    ks_f, om_f, (w, w1, w2, w3) = band_derivatives()
    print(f"\nbande liee autour de k0={K0}:")
    print(f"  omega   = {w:+.6f}")
    print(f"  omega'  = {w1:+.6f}   (vitesse de groupe)")
    print(f"  omega'' = {w2:+.6f}   (courbure -> masse effective)")
    print(f"  omega'''= {w3:+.6f}   (proprietaire de l'ecart Schrodinger)")

    psi0, ks, A, oms, slabs = C.make_packet(NX, NY, NZ, PHI, TAU, K0, SIGK, nmodes=11)
    w_wt = A ** 2 / np.sum(A ** 2)
    print(f"\npaquet: {len(ks)} modes, k in [{ks[0]:.3f},{ks[-1]:.3f}]")

    # derivees locales de la bande aux k du paquet (une seule convention de fit)
    dom = np.array([C.polyfit_band(ks_f, om_f, k, deg=4)[1] for k in ks])
    var_wprime = float(np.sum(w_wt * dom ** 2) - np.sum(w_wt * dom) ** 2)
    print(f"  Var_w(omega') = {var_wprime:.6e}   (predicteur exact d'etalement)")

    U = C.build_full_map(NX, NY, NZ, PHI, TAU)
    print(f"  carte complete: nnz = {U.nnz}")

    rho0, z0, s0 = C.z_moments(psi0, NX, NY, NZ)
    psi = psi0.copy()
    samples = []
    for t in range(1, T + 1):
        psi = U @ psi
        if t % (T // 20) == 0:
            _, zb, s2 = C.z_moments(psi, NX, NY, NZ)
            samples.append((t, zb, s2))

    print("\n(i) variance de position -- mesure vs loi dispersive exacte")
    print("   t     sigma^2 mesure   exact           Schrodinger")
    worst = 0.0
    for t, zb, s2 in samples:
        ex = s0 + t ** 2 * var_wprime
        sc = s0 + t ** 2 * (w2 ** 2) * SIGK ** 2
        worst = max(worst, abs(s2 - ex) / s0)
        print(f"  {t:4d}   {s2:12.4f}   {ex:12.4f}   {sc:12.4f}")
    print(f"  residu max de la loi exacte: {worst*100:.4f} % de sigma0^2")

    # (ii) transport modal
    print("\n(ii) transport modal (linearite de U sur la bande)")
    Bs = np.array([C.bloch_state(k, NX, NY, NZ, PHI, TAU)[0] for k in ks])
    Bs = Bs / np.linalg.norm(Bs, axis=1, keepdims=True)
    A0 = Bs.conj() @ psi0
    AT = Bs.conj() @ psi
    ampl = np.max(np.abs(np.abs(AT) / np.abs(A0) - 1))
    phase = np.max(np.abs(((np.angle(AT) - np.angle(A0) - oms * T + np.pi)
                           % (2 * np.pi)) - np.pi))
    print(f"  max | |A_k|(T)/|A_k|(0) - 1 | = {ampl:.3e}")
    print(f"  max | arg A_k - omega_k T |   = {phase:.3e} rad")

    # (iii) interference
    print("\n(iii) interference de deux paquets (k = 1.3 et 1.7)")
    p1, _, _, _, _ = C.make_packet(NX, NY, NZ, PHI, TAU, 1.30, SIGK, nmodes=7)
    p2, _, _, _, _ = C.make_packet(NX, NY, NZ, PHI, TAU, 1.70, SIGK, nmodes=7)
    s12 = (p1 + p2) / np.linalg.norm(p1 + p2)
    for _ in range(60):
        p1 = U @ p1; p2 = U @ p2; s12 = U @ s12
    n = np.linalg.norm(p1 + p2)
    r1, _, _ = C.z_moments(p1, NX, NY, NZ)
    r2, _, _ = C.z_moments(p2, NX, NY, NZ)
    r12, _, _ = C.z_moments((p1 + p2) / n, NX, NY, NZ)
    w1_ = np.linalg.norm(p1) ** 2 / n ** 2
    w2_ = np.linalg.norm(p2) ** 2 / n ** 2
    Cz = r12 - w1_ * r1 - w2_ * r2
    env = np.abs(np.fft.rfft(Cz))
    kpk = 2 * np.pi * int(np.argmax(env[1:]) + 1) / NZ
    P = (p1.reshape(NX, NY, NZ, 12) * np.conj(p2.reshape(NX, NY, NZ, 12))).sum(axis=(0, 1, 3))
    pred = 2 * np.real(P) / n ** 2
    corr = float(np.corrcoef(Cz, pred)[0, 1])
    print(f"  pic de Fourier du terme croise: k = {kpk:.4f}   (|k2-k1| = 0.4000)")
    print(f"  correlation( C(z), 2 Re[env1 env2*] ) = {corr:.5f}")

    np.savez("/home/claude/scn/calc1_out.npz", ks=ks, oms=oms, ks_f=ks_f, om_f=om_f,
             samples=np.array(samples), var_wprime=var_wprime, sigma0=s0,
             deriv=np.array([w, w1, w2, w3]))
    print("\n-> calc1_out.npz")


if __name__ == "__main__":
    main()
