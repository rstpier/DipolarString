"""
calc1b.py -- variantes et resultats negatifs de l'annexe E.

(A) Hierarchie des residus de phase: la troncature quadratique (Schrodinger) laisse
    un residu; ajouter le terme cubique le divise; le reste est compatible avec le
    quartique. C'est ce qui attribue l'ecart de calc1 a omega''' et non a un defaut
    de la construction.
(B) Convergence en taille transverse: la bande liee et sa courbure sont-elles
    convergees a Nx = 9, 11, ... ?
(C) Resultat negatif n.1 -- la bande liee ne peut pas fournir un potentiel de
    Coulomb: deux defauts dans le meme plan transverse donnent un doublet
    liant/antiliant dont l'ecart t(d) decroit EXPONENTIELLEMENT avec la distance.
    Mesure aussi la suppression du couplage entre chiralites de tressage opposees.

RECONSTRUCTION 31/08/2026. Usage: python3 calc1b.py
"""

import numpy as np
import calc1_common as C

NZ = 128
PHI = 1.3
K0, SIGK = 1.5, 0.15


def part_A(Nx=9, Ny=9, T=240):
    print("\n(A) hierarchie des residus de phase")
    ks_f = np.linspace(K0 - 0.45, K0 + 0.45, 13)
    ks_f, om_f, _ = C.defect_band(ks_f, Nx=Nx, Ny=Ny, phi=PHI, tau=0.0)
    w, w1, w2, w3 = C.polyfit_band(ks_f, om_f, K0, deg=4)

    psi0, ks, A, oms, _ = C.make_packet(Nx, Ny, NZ, PHI, 0.0, K0, SIGK, nmodes=11)
    dk = ks - K0
    for name, model in [
        ("lineaire   (transport pur)", w + w1 * dk),
        ("quadratique (Schrodinger) ", w + w1 * dk + w2 * dk ** 2 / 2),
        ("+ cubique                 ", w + w1 * dk + w2 * dk ** 2 / 2 + w3 * dk ** 3 / 6),
    ]:
        res = np.max(np.abs((oms - model) * T))
        print(f"  {name}: max |Delta phase| a t={T} = {res:.4f} rad")
    print("  (chaque terme ajoute divise le residu -> l'ecart de calc1 appartient")
    print("   bien au developpement de la bande, pas a la carte)")
    return w2


def part_B():
    print("\n(B) convergence en taille transverse de la bande liee")
    print("  Nx=Ny   omega(k0)     omega'       omega''      localisation")
    prev = None
    for N in (7, 9, 11):
        ks = np.linspace(K0 - 0.45, K0 + 0.45, 13)
        ks, om, vecs = C.defect_band(ks, Nx=N, Ny=N, phi=PHI, tau=0.0)
        w, w1, w2, w3 = C.polyfit_band(ks, om, K0, deg=4)
        x0 = y0 = N // 2
        idxd = [(x0 * N + y0) * 12 + q for q in range(12)]
        v = vecs[len(vecs) // 2]
        loc = float(np.sum(np.abs(v[idxd]) ** 2))
        d = "" if prev is None else f"   (d omega''/omega'' = {abs(w2-prev)/abs(w2):.2e})"
        print(f"   {N:2d}    {w:+.6f}   {w1:+.6f}   {w2:+.6f}   {loc:.3f}{d}")
        prev = w2


def two_defect_split(N, d, phi=PHI, tau1=0.0, tau2=0.0, kz=2 * np.pi / 3):
    """Doublet liant/antiliant de deux defauts droits separes de d mailles dans
    le plan transverse. Retourne l'ecart |omega_+ - omega_-|."""
    n = N * N * 12
    S = C.S_JOHNS.astype(complex)
    D1 = C.defect_node(phi, tau1)
    D2 = C.defect_node(phi, tau2)
    x1, y0 = N // 2 - d // 2, N // 2
    x2 = x1 + d

    def vid(x, y, pt):
        return (x * N + y) * 12 + C.PIDX[pt]

    def node(x, y):
        if x == x1 and y == y0: return D1
        if x == x2 and y == y0: return D2
        return S

    U = np.zeros((n, n), complex)
    for x in range(N):
        for y in range(N):
            for (a, s, p) in C.PORTS:
                e = [0, 0, 0]; e[a] = s
                if a == 2:
                    x2n, y2n = x, y; ph = np.exp(-1j * s * kz)
                else:
                    x2n, y2n = (x + e[0]) % N, (y + e[1]) % N; ph = 1.0
                Ss = node(x2n, y2n)
                row = vid(x, y, (a, s, p)); src = C.PIDX[(a, -s, p)]
                for j in range(12):
                    c = Ss[src, j]
                    if c != 0:
                        U[row, vid(x2n, y2n, C.PORTS[j])] += ph * c
    lam, W = np.linalg.eig(U)
    W = W / np.linalg.norm(W, axis=0)
    th = np.angle(lam)
    idx = [vid(x1, y0, pt) for pt in C.PORTS] + [vid(x2, y0, pt) for pt in C.PORTS]
    loc = np.sum(np.abs(W[idx, :]) ** 2, axis=0)
    cand = np.where((th > 2.40) & (th < np.pi - 1e-6))[0]
    cand = cand[np.argsort(-loc[cand])][:2]
    if len(cand) < 2:
        return np.nan
    return float(abs(th[cand[0]] - th[cand[1]]))


def part_C():
    print("\n(C) resultat negatif n.1 -- couplage entre deux defauts")
    print("   d   split (meme chiralite)   split (chiralites opposees)   rapport")
    ds, ts, to = [], [], []
    for d in (2, 3, 4, 5, 6):
        N = max(15, d + 9)
        a = two_defect_split(N, d, tau1=0.0, tau2=0.0)
        b = two_defect_split(N, d, tau1=0.0, tau2=np.pi / 2)
        ds.append(d); ts.append(a); to.append(b)
        r = a / b if b and np.isfinite(b) and b > 0 else np.nan
        print(f"   {d}     {a:.6e}            {b:.6e}          {r:.1f}")
    ds = np.array(ds, float); ts = np.array(ts)
    ok = np.isfinite(ts) & (ts > 0)
    ce = np.polyfit(ds[ok], np.log(ts[ok]), 1)
    cp = np.polyfit(np.log(ds[ok]), np.log(ts[ok]), 1)
    ye = np.polyval(ce, ds[ok]); yp = np.polyval(cp, np.log(ds[ok]))
    r2 = lambda y, yh: 1 - np.sum((y - yh) ** 2) / np.sum((y - y.mean()) ** 2)
    ly = np.log(ts[ok])
    print(f"\n  ajustement exponentiel: t ~ exp({ce[0]:+.4f} d)   R2 = {r2(ly, ye):.4f}")
    print(f"  ajustement en puissance: t ~ d^({cp[0]:+.3f})       R2 = {r2(ly, yp):.4f}")
    print("  => decroissance exponentielle: 1/d est EXCLU. Le potentiel de Coulomb")
    print("     ne peut pas venir de la bande liee; il doit venir du secteur de charge.")


if __name__ == "__main__":
    print("=" * 68)
    print("calc1b -- variantes, convergence, resultats negatifs")
    print("=" * 68)
    part_A()
    part_B()
    part_C()
