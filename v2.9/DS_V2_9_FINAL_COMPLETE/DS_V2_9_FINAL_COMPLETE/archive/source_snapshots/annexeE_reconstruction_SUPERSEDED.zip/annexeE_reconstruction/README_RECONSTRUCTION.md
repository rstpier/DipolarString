# Annexe E — scripts reconstruits (31/08/2026)

**Statut : reconstruction, pas les originaux.** Les scripts V2.8 (`calc1.py`,
`calc1b.py`, `calc2.py`, `calc3.py`, `calc1_common.py`) ne sont archivés que sur
Zenodo (concept DOI 10.5281/zenodo.21196098) ; ils ne sont ni sur le dépôt GitHub
(qui s'arrête à V2.7) ni en local. Ces cinq fichiers reproduisent la
**construction décrite dans l'annexe**, pas son code. Les chiffres ci-dessous sont
ceux mesurés par cette reconstruction, à confronter à ceux du manuscrit.

## Ce que chaque script fait

| fichier | rôle |
|---|---|
| `calc1_common.py` | ports SCN, reconstruction de la matrice de Johns depuis E→+1 / H→−1 + covariance cubique, défaut de ligne tressé, carte de Bloch en repère tournant, carte complète du réseau (creuse), assemblage de paquets |
| `calc1.py` | enveloppe libre : loi dispersive exacte vs troncature Schrödinger, transport modal, interférence de deux paquets |
| `calc1b.py` | hiérarchie des résidus de phase, convergence en taille transverse, résultat négatif n°1 (couplage entre deux défauts) |
| `calc3.py` | quantum d'action unique : de Broglie statique, équation de Hamilton sous force de jauge, réponse inertielle |
| `calc2.py` | potentiel externe : bosse, puits, état lié dans l'opérateur effectif tronqué |

## Résultats mesurés

**Matrice de Johns** — reconstruite, unique : symétrique, orthogonale, involutive,
spectre 6×(+1) / 6×(−1), diagonale nulle, E→+1 et H→−1 exacts.

**calc1** (maillage 9×9×128, 124 416 amplitudes) — bande liée à k₀=1,5 :
ω=2,950010, ω′=−0,169336, ω″=+0,044990, ω‴=+0,174950.
- loi dispersive exacte σ²(t) = σ₀² + t²·Var_w(ω′) : résidu max **0,32 %** de σ₀²
  sur 480 pas ; la troncature Schrödinger dévie visiblement (38,6 mesuré contre
  43,9 prédit par la troncature à t=480) — l'écart appartient à ω‴.
- transport modal : |A_k| constant à **1,3×10⁻¹⁴**, arg A_k = ω_k t à **1,5×10⁻¹²** rad.
- interférence : corrélation avec 2 Re[env₁env₂*] = **1,00000** ; pic de Fourier
  à k=0,4418 contre |k₂−k₁|=0,4000 (une case d'anneau).

**calc1b** —
- résidus de phase à t=240 : linéaire 0,5186 → quadratique 0,1333 → +cubique
  **0,0002** rad. Chaque terme divise le résidu : l'écart de calc1 est bien dans le
  développement de la bande, pas dans la carte.
- convergence transverse : ω″ varie de 5,8×10⁻⁴ (7→9) puis 1,1×10⁻⁴ (9→11) ;
  localisation sur la colonne du défaut stable à 0,316.
- deux défauts : splitting **7,6×10⁻⁴ à d=2 → 9,0×10⁻⁵ à d=6**. Ni exponentiel
  propre (R²=0,19) ni loi de puissance propre (R²=0,21) — la décroissance est
  rapide et non monotone (artefact de parité de sous-réseau, déjà rencontré en
  juillet). **La conclusion structurelle tient** : ce n'est pas 1/d, donc le
  potentiel de Coulomb ne peut pas venir de la bande liée. Mais la loi exponentielle
  nette de l'annexe n'est pas reproduite ici.
- chiralités opposées : suppression croissante avec d (rapport 23× à d=4, 95× à
  d=5, 343× à d=6) — même sens que le facteur ≈14 de l'annexe, valeur différente.

**calc3** — un seul quantum d'action :
- statique : E/N vs ω(k₀) à **0,24 %**, P/N vs k̄ à **0,04 %**, même N des deux côtés.
- Hamilton sous jauge (α=4×10⁻⁴/pas, balayage k : 1,50 → 1,05) : v(t) suit
  ω′(k_eff) point par point à **≤0,58 %**.
- inertie : m_F·ω″ = **1,032** en moyenne, intervalle [0,947 ; 1,188]. Le point large
  est celui où ω″ traverse zéro (k≈1,25) et où m_F diverge — c'est une singularité
  réelle du point d'inflexion, pas une erreur.
- norme conservée à 1,00000000 : la jauge ne travaille pas.

**calc2** — potentiel externe :
- bosse V₀=+0,015 : retard réseau **+1,92** pas vs enveloppe **+1,97**, corrélation
  des densités **0,99832**, 98,1 % resté sur la bande.
- puits V₀=−0,015 : retard **−1,44** vs **−1,47**, corrélation **0,99828**, 98,4 %
  sur la bande. Asymétrie puits/bosse mesurée : couplage hors bande **×0,86** —
  autrement dit aucune asymétrie, le verdict est rendu par comparaison directe des
  deux signes et non par un seuil arbitraire.
- état lié (puits V₀=0,030) : ω=2,84221, **71 %** du poids dans le puits, décalage
  −0,108 sous le fond de bande.

## Écarts avec l'annexe V2.8 — à ne pas masquer

1. **L'asymétrie bosse/puits n'est pas reproduite.** L'annexe rapporte que le puits
   couple 0,78 % hors bande et dégrade le modèle (retard 8,0 vs 5,1). Ici les deux
   signes se comportent identiquement. Le seuil de rupture à une bande dépend du
   profil exact du défaut, que cette reconstruction ne prétend pas égaler : **il
   doit être remesuré, pas cité depuis l'annexe.**
2. **Le facteur 14** entre chiralités devient ici 23–343 selon la distance, avec un
   changement de régime à d=4. Même signe, valeur différente.
3. **La loi exponentielle** du splitting (annexe : exposant ≈−4,7 en loi de
   puissance, exclusion de 1/d) n'a pas ici d'ajustement propre.

Le paramètre de désaccord φ=1,3 et le tressage τ=π/8 sont mes choix ; l'annexe ne
les donne pas. Les trois écarts ci-dessus se referment probablement en récupérant
le paquet Zenodo — c'est la seule façon de trancher.

## Reproduction

```
python3 calc1_common.py   # vérifie la matrice de Johns
python3 calc1.py          # ~7 min
python3 calc1b.py         # ~25 min
python3 calc3.py          # ~5 min
python3 calc2.py          # ~7 min
```

Dépendances : voir `requirements.txt`. Environnement de test exact dans
`environnement.txt` (Python 3.12.3, numpy 2.4.4, scipy 1.17.1).

Les trois `.log` joints sont les sorties réelles des exécutions du 31/08/2026 —
c'est contre elles qu'il faut comparer si tu relances.
