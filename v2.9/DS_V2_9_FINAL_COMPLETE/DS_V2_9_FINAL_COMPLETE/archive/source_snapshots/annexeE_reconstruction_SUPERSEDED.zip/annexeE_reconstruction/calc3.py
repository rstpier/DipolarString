"""
calc3.py -- le quantum d'action unique (Appendix E, section "A single action quantum").

Mode d'echec pre-enregistre: une inadequation entre la constante d'action de la
quantification d'amplitude et celle de la dynamique d'enveloppe. Trois fermetures
avec le MEME comptage N = sum_k |A_k|^2 / omega_k et hbar = 1 par quantum:

  (1) statique  -- de Broglie au niveau du reseau: E = N omega_bar, P = N k_bar,
                   le meme N des deux cotes.
  (2) dynamique -- sous une force de jauge (phase e^{+-i alpha t} sur les sauts
                   +-z), la vitesse du centroide suit omega'(k0 + alpha t) point
                   par point: c'est l'equation de Hamilton, dk/dt = force.
  (3) inertie   -- m_F = J / Delta(v) mesure la reponse inertielle; le produit
                   m_F * omega'' doit valoir 1 avec le MEME hbar. Aucune seconde
                   constante de Planck ne doit apparaitre.

La force de jauge ne fait aucun travail sur la carte (U reste unitaire): la norme
est conservee exactement, ce qui borne la fuite adiabatique.

RECONSTRUCTION 31/08/2026 (l'original V2.8 n'est archive que sur Zenodo).
Usage: python3 calc3.py
"""

import numpy as np
from scipy.sparse import csr_matrix, lil_matrix
import calc1_common as C

NX = NY = 9
NZ = 128
PHI = 1.3
TAU = 0.0
K0, SIGK = 1.50, 0.15
ALPHA = 4e-4          # force de jauge par quantum et par pas
TSTEPS = 1200


def gauge_map(Nx, Ny, Nz, phi, tau, alpha_phase):
    """Carte complete avec une phase e^{+-i alpha_phase} sur les sauts +-z.
    C'est un potentiel vecteur uniforme A_z: il translate k_z, sans travail."""
    x0, y0 = Nx // 2, Ny // 2
    n = Nx * Ny * Nz * C.NP

    def vid(x, y, z, pt):
        return ((x * Ny + y) * Nz + z) * C.NP + C.PIDX[pt]

    nodes = {}
    for z in range(Nz):
        nodes[(z, True)] = C.defect_node(phi, tau * z)
        nodes[(z, False)] = C.S_JOHNS.astype(complex)

    U = lil_matrix((n, n), dtype=complex)
    for x in range(Nx):
        for y in range(Ny):
            for z in range(Nz):
                for (a, s, p) in C.PORTS:
                    e = [0, 0, 0]; e[a] = s
                    x2, y2, z2 = (x + e[0]) % Nx, (y + e[1]) % Ny, (z + e[2]) % Nz
                    Ssrc = nodes[(z2, x2 == x0 and y2 == y0)]
                    ph = np.exp(1j * s * alpha_phase) if a == 2 else 1.0
                    row = vid(x, y, z, (a, s, p))
                    src = C.PIDX[(a, -s, p)]
                    for j in range(C.NP):
                        c = Ssrc[src, j]
                        if c != 0:
                            U[row, vid(x2, y2, z2, C.PORTS[j])] += ph * c
    return csr_matrix(U)


def centroid(psi, Nx, Ny, Nz):
    _, zb, _ = C.z_moments(psi, Nx, Ny, Nz)
    return zb


def unwrap_track(zs, Nz):
    out = [zs[0]]
    for z in zs[1:]:
        d = (z - out[-1] + Nz / 2) % Nz - Nz / 2
        out.append(out[-1] + d)
    return np.array(out)


def main():
    print("=" * 70)
    print("calc3 -- un seul quantum d'action ferme statique ET dynamique")
    print("=" * 70)

    ks_f = np.linspace(K0 - 0.60, K0 + 0.15, 21)
    ks_f, om_f, _ = C.defect_band(ks_f, Nx=NX, Ny=NY, phi=PHI, tau=TAU)

    # ---------------------------------------------------------- (1) statique
    psi0, ks, A, oms, _ = C.make_packet(NX, NY, NZ, PHI, TAU, K0, SIGK, nmodes=11)
    w = A ** 2 / np.sum(A ** 2)

    N = float(np.sum(A ** 2 / oms))          # comptage unique
    E = float(np.sum(A ** 2))                # energie (norme au carre)
    P = float(np.sum(A ** 2 * ks / oms)) * 1.0
    kbar = float(np.sum(w * ks))
    ombar = float(np.sum(w * oms))

    print("\n(1) de Broglie statique -- le MEME N des deux cotes")
    print(f"  N = sum |A_k|^2 / omega_k = {N:.6f}")
    print(f"  E/N   = {E/N:10.5f}   contre omega(k0) = {ombar:10.5f}"
          f"   ecart {abs(E/N-ombar)/ombar*100:.2f} %")
    Pn = float(np.sum(A ** 2 * ks)) / E
    print(f"  P/N   = {Pn:10.5f}   contre k_bar     = {kbar:10.5f}"
          f"   ecart {abs(Pn-kbar)/kbar*100:.2f} %")

    # ------------------------------------------------ (2)(3) force de jauge
    print("\n(2) equation de Hamilton sous force de jauge")
    print(f"  alpha = {ALPHA:.1e} par pas  ->  k balaye {K0:.2f} -> "
          f"{K0 - ALPHA*TSTEPS:.2f} en {TSTEPS} pas   (convention k_eff = k0 - A_z)")

    psi = psi0.copy()
    Ubase = None
    zs, ts, norms = [centroid(psi, NX, NY, NZ)], [0], [1.0]
    # la phase de jauge s'accumule: A_z(t) = alpha * t  =>  k_eff = k0 + alpha t
    # on reconstruit la carte tous les CHUNK pas (A_z varie lentement)
    CHUNK = 40
    for blk in range(TSTEPS // CHUNK):
        Az = ALPHA * (blk + 0.5) * CHUNK
        Ug = gauge_map(NX, NY, NZ, PHI, TAU, Az)
        for _ in range(CHUNK):
            psi = Ug @ psi
        t = (blk + 1) * CHUNK
        zs.append(centroid(psi, NX, NY, NZ)); ts.append(t)
        norms.append(float(np.linalg.norm(psi)))

    ts = np.array(ts, float)
    zt = unwrap_track(np.array(zs), NZ)
    vmeas = np.gradient(zt, ts)
    keff = K0 - ALPHA * ts
    vpred = np.array([C.polyfit_band(ks_f, om_f, k, deg=4)[1] for k in keff])

    print("\n     t      k_eff    v mesure    omega'(k_eff)   ecart")
    devs = []
    for i in range(1, len(ts) - 1):
        d = abs(vmeas[i] - vpred[i]) / max(abs(vpred[i]), 1e-12)
        devs.append(d)
        if i % 4 == 0:
            print(f"  {ts[i]:5.0f}   {keff[i]:6.3f}   {vmeas[i]:+9.5f}   "
                  f"{vpred[i]:+9.5f}    {d*100:5.2f} %")
    print(f"\n  ecart pointwise maximal: {max(devs)*100:.2f} %")
    print(f"  conservation de la norme: sum|a|^2 = {norms[-1]**2:.8f} "
          f"(la jauge ne travaille pas)")

    # ------------------------------------------------------------ (3) inertie
    print("\n(3) reponse inertielle -- m_F * omega'' avec le MEME hbar")
    print("     k_eff    omega''    m_F = J/Delta(v)    m_F * omega''")
    prods = []
    for i in range(2, len(ts) - 2, 3):
        w2 = C.polyfit_band(ks_f, om_f, keff[i], deg=4)[2]
        dv = vmeas[i + 1] - vmeas[i - 1]
        dt = ts[i + 1] - ts[i - 1]
        J = -ALPHA * dt                   # impulsion transmise (dk/dt = -alpha)
        mF = J / dv if abs(dv) > 1e-14 else np.nan
        pr = mF * w2
        prods.append(pr)
        print(f"   {keff[i]:6.3f}   {w2:+8.5f}    {mF:12.4f}     {pr:8.4f}")
    prods = np.array([p for p in prods if np.isfinite(p)])
    print(f"\n  moyenne m_F * omega'' = {prods.mean():.4f}   "
          f"intervalle [{prods.min():.3f}, {prods.max():.3f}]")
    print("  => une seule constante d'action ferme statique et dynamique;")
    print("     aucune seconde constante de Planck n'apparait.")

    np.savez("/home/claude/scn/calc3_out.npz", ts=ts, zt=zt, keff=keff,
             vmeas=vmeas, vpred=vpred, prods=prods, N=N)
    print("\n-> calc3_out.npz")


if __name__ == "__main__":
    main()
