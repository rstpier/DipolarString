"""
calc1_common.py -- module partage de l'annexe "Emergent Single-Band Schrodinger
Dynamics of the Braided-Defect Envelope" (DS model, Appendix E).

RECONSTRUCTION (31/08/2026). Les scripts originaux de la V2.8 ne sont archives
que sur Zenodo (concept DOI 10.5281/zenodo.21196098). Ce module reproduit la
construction decrite dans l'annexe -- reseau de Johns 3D, defaut de ligne tresse,
carte scatter-propagate exacte -- sans pretendre etre identique octet pour octet
a l'original.

Contenu:
  - ports du noeud condense symetrique (SCN), 12 par cellule
  - reconstruction de la matrice de Johns S depuis les seules contraintes
    E -> +1, H -> -1 et la covariance cubique (methode step1 du 30/08)
  - defaut de ligne tresse: colonne centrale dont l'axe directeur transverse
    tourne le long de z (desaccord d'impedance anisotrope)
  - carte de Bloch a k_z fixe dans le repere tournant (jauge qui absorbe le
    tressage), d'ou la bande liee omega(k_z)
  - carte complete U du reseau (sparse) pour la propagation reelle
"""

import numpy as np
import itertools
from scipy.sparse import lil_matrix, csr_matrix

# ---------------------------------------------------------------- ports SCN
# port = (a, s, p): axe a, face s = +-1, polarisation p (p != a)
PORTS = [(a, s, p) for a in range(3) for s in (1, -1) for p in range(3) if p != a]
PIDX = {pt: i for i, pt in enumerate(PORTS)}
NP = 12

_LC = np.zeros((3, 3, 3))
for _a in range(3):
    for _b in range(3):
        for _c in range(3):
            if len({_a, _b, _c}) == 3:
                _LC[_a, _b, _c] = 1.0 if [_a, _b, _c] in ([0, 1, 2], [1, 2, 0], [2, 0, 1]) else -1.0


def em_modes():
    """Modes E (uniformes par polarisation) et H (circulation signee w_q)."""
    E = np.zeros((3, NP))
    H = np.zeros((3, NP))
    for i, (a, s, p) in enumerate(PORTS):
        E[p, i] = 1.0
        for q in range(3):
            H[q, i] += s * _LC[a, p, q]
    return E, H


def _cubic_reps():
    """Representation a 12 dim des generateurs du groupe cubique + inversion."""
    Rz = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
    Rx = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]])
    Inv = -np.eye(3)
    mats = []
    for R in (Rz, Rx, Inv):
        M = np.zeros((NP, NP))
        for i, (a, s, p) in enumerate(PORTS):
            v = np.zeros(3); v[a] = s; v2 = R @ v
            a2 = int(np.argmax(np.abs(v2))); s2 = int(np.sign(v2[a2]))
            w = np.zeros(3); w[p] = 1; w2 = R @ w
            p2 = int(np.argmax(np.abs(w2))); sg = np.sign(w2[p2])
            M[PIDX[(a2, s2, p2)], i] = sg
        mats.append(M)
    return mats


def johns_matrix():
    """S de Johns, reconstruite depuis E->+1, H->-1, covariance cubique.
    Retourne l'unique solution 6/6 a diagonale nulle."""
    E, H = em_modes()
    half = 0.5
    row_cands = [[] for _ in range(NP)]
    for i in range(NP):
        for supp in itertools.combinations(range(NP), 4):
            for signs in itertools.product((half, -half), repeat=4):
                row = np.zeros(NP)
                for pos, sg in zip(supp, signs):
                    row[pos] = sg
                if any(abs(row @ E[j] - E[j, i]) > 1e-12 for j in range(3)):
                    continue
                if any(abs(row @ H[q] + H[q, i]) > 1e-12 for q in range(3)):
                    continue
                row_cands[i].append(row)

    sols = []
    S = np.zeros((NP, NP))

    def bt(i):
        if i == NP:
            sols.append(S.copy()); return
        for row in row_cands[i]:
            if any(abs(row[j] - S[j, i]) > 1e-12 for j in range(i)):
                continue
            if any(abs(row @ S[j]) > 1e-12 for j in range(i)):
                continue
            S[i, :] = row
            bt(i + 1)
            S[i, :] = 0
            if len(sols) >= 50:
                return
    bt(0)

    reps = _cubic_reps()
    good = [Sc for Sc in sols
            if all(np.allclose(M @ Sc @ M.T, Sc) for M in reps)
            and int(np.sum(np.linalg.eigvalsh(Sc) > 0)) == 6
            and np.allclose(np.diag(Sc), 0)]
    if not good:
        raise RuntimeError("reconstruction de S echouee")
    return good[0]


S_JOHNS = johns_matrix()


# ------------------------------------------------------- defaut de ligne tresse
def pol_rotation(theta):
    """Rotation d'angle theta dans le sous-espace transverse span{E_x, E_y} du
    noeud, identite ailleurs. Ce sous-espace est celui des modes E de Johns
    (vecteurs propres +1 de S), il est stable sous la permutation de propagation
    s -> -s : la jauge du tressage est donc exacte."""
    E, _ = em_modes()
    ex = E[0] / np.linalg.norm(E[0])
    ey = E[1] / np.linalg.norm(E[1])
    c, s_ = np.cos(theta), np.sin(theta)
    R = np.eye(NP)
    R += (c - 1) * (np.outer(ex, ex) + np.outer(ey, ey))
    R += s_ * (np.outer(ey, ex) - np.outer(ex, ey))
    return R


def defect_node(phi, theta):
    """Noeud du defaut: desaccord d'impedance ANISOTROPE d'amplitude phi, d'axe
    directeur n(theta) dans le plan transverse. Le mode E le long de n prend la
    phase e^{+i phi}, le mode orthogonal e^{-i phi}. Le tressage de l'annexe est
    theta = tau * z."""
    E, _ = em_modes()
    ex = E[0] / np.linalg.norm(E[0])
    ey = E[1] / np.linalg.norm(E[1])
    n = np.cos(theta) * ex + np.sin(theta) * ey
    m = -np.sin(theta) * ex + np.cos(theta) * ey
    D = np.eye(NP, dtype=complex)
    D += (np.exp(1j * phi) - 1) * np.outer(n, n)
    D += (np.exp(-1j * phi) - 1) * np.outer(m, m)
    return D @ S_JOHNS.astype(complex)


# ------------------------------------------------- carte de Bloch (repere tournant)
def bloch_map(kz, Nx, Ny, phi, tau, x0=None, y0=None):
    """Carte de transfert d'une tranche z, a k_z fixe, dans le repere tournant
    (la rotation tau par pas est absorbee dans la jauge => carte independante de z).
    Dimension: Nx*Ny*12."""
    if x0 is None: x0 = Nx // 2
    if y0 is None: y0 = Ny // 2
    n = Nx * Ny * NP
    Sdef = defect_node(phi, 0.0)     # dans le repere tournant, theta = 0 partout
    Rg = {+1: pol_rotation(-tau).astype(complex),
          -1: pol_rotation(+tau).astype(complex)}   # jauge portee par le saut en z

    def vid(x, y, pt):
        return (x * Ny + y) * NP + PIDX[pt]

    def node_at(xx, yy):
        return Sdef if (xx == x0 and yy == y0) else S_JOHNS.astype(complex)

    U = np.zeros((n, n), complex)
    for x in range(Nx):
        for y in range(Ny):
            for i, (a, s, p) in enumerate(PORTS):
                # amplitude entrante (a,s,p) au site (x,y) <- sortie du voisin
                e = [0, 0, 0]; e[a] = s
                x2, y2 = x + e[0], y + e[1]
                if a == 2:
                    x2, y2 = x, y     # axe z: phase de Bloch + rotation de jauge
                    ph = np.exp(-1j * s * kz)
                else:
                    ph = 1.0
                    x2, y2 = x2 % Nx, y2 % Ny    # tore transverse: U reste unitaire
                row = vid(x, y, (a, s, p))
                src = PIDX[(a, -s, p)]
                Ssrc = node_at(x2, y2)      # le noeud qui EMET est celui du voisin
                if a == 2:
                    Ssrc = Rg[s] @ Ssrc     # la jauge agit sur le saut en z
                for j in range(NP):
                    c = Ssrc[src, j]
                    if c != 0:
                        U[row, vid(x2, y2, PORTS[j])] += ph * c
    return U


def defect_band(kzs, Nx=11, Ny=11, phi=1.3, tau=np.pi / 8, verbose=False,
                gap_min=2.40, gap_max=np.pi - 1e-6):
    """Bande liee du defaut tresse, par continuation de vecteur propre.

    La bande vit dans le gap du continuum transverse (par defaut [2.40, pi]),
    ou l'etat est veritablement lie: poids sur la colonne du defaut ~0.3 contre
    ~12/(12 Nx Ny) pour un etat delocalise. Retourne (kzs, omega, vecteurs)."""
    kzs = np.asarray(kzs, float)
    om = np.zeros(len(kzs))
    vecs = []
    x0, y0 = Nx // 2, Ny // 2
    idxd = [(x0 * Ny + y0) * NP + q for q in range(NP)]
    ref = None
    for m, kz in enumerate(kzs):
        U = bloch_map(kz, Nx, Ny, phi, tau, x0, y0)
        lam, W = np.linalg.eig(U)
        W = W / np.linalg.norm(W, axis=0)
        th = np.angle(lam)
        loc = np.sum(np.abs(W[idxd, :]) ** 2, axis=0)
        if ref is None:
            cand = np.where((th > gap_min) & (th < gap_max))[0]
            if len(cand) == 0:
                raise RuntimeError(f"aucun etat dans le gap a kz={kz}")
            c = int(cand[np.argmax(loc[cand])])
        else:
            ov = np.abs(ref.conj() @ W)
            c = int(np.argmax(ov))
        v = W[:, c]
        ref = v
        om[m] = th[c]
        vecs.append(v)
        if verbose:
            print(f"  kz={kz:.4f}  omega={th[c]:+.6f}  localisation={loc[c]:.3f}")
    return kzs, om, vecs


def polyfit_band(kzs, om, k0, deg=4, win=0.35):
    """Ajustement polynomial local de la bande autour de k0.
    Retourne (omega, omega', omega'', omega''')."""
    sel = np.abs(kzs - k0) < win
    if np.sum(sel) < deg + 1:
        sel = np.argsort(np.abs(kzs - k0))[:deg + 3]
    c = np.polyfit(kzs[sel] - k0, om[sel], deg)
    p = np.poly1d(c)
    return p(0), p.deriv(1)(0), p.deriv(2)(0), p.deriv(3)(0)


if __name__ == "__main__":
    S = S_JOHNS
    print("S de Johns reconstruite.")
    print("  symetrique :", np.allclose(S, S.T))
    print("  orthogonale:", np.allclose(S @ S.T, np.eye(NP)))
    print("  involutive :", np.allclose(S @ S, np.eye(NP)))
    print("  spectre    :", np.round(np.sort(np.linalg.eigvalsh(S)), 8))
    print("  diag nulle :", np.allclose(np.diag(S), 0))
    E, H = em_modes()
    print("  E -> +1    :", np.allclose(S @ E.T, E.T))
    print("  H -> -1    :", np.allclose(S @ H.T, -H.T))


# ------------------------------------------------ carte complete du reseau 3D
def build_full_map(Nx=11, Ny=11, Nz=128, phi=1.3, tau=np.pi / 8, Vprofile=None):
    """Carte scatter-propagate exacte du reseau de Johns avec defaut de ligne
    tresse (theta = tau * z sur la colonne centrale). Conditions periodiques en
    x, y, z. tau * Nz doit etre un multiple de 2*pi (tressage commensurable).

    Vprofile : tableau de longueur Nz, modulation locale de frequence (potentiel
    externe) appliquee comme phase e^{i V(z)} sur tous les canaux du plan z.
    Retourne une matrice creuse (csr) de dimension Nx*Ny*Nz*12."""
    assert abs((tau * Nz) % (2 * np.pi)) < 1e-9 or abs((tau * Nz) % (2 * np.pi) - 2 * np.pi) < 1e-9, \
        "tressage non commensurable avec Nz"
    x0, y0 = Nx // 2, Ny // 2
    n = Nx * Ny * Nz * NP

    def vid(x, y, z, pt):
        return ((x * Ny + y) * Nz + z) * NP + PIDX[pt]

    nodes = {}
    for z in range(Nz):
        nodes[(z, True)] = defect_node(phi, tau * z)
        nodes[(z, False)] = S_JOHNS.astype(complex)

    U = lil_matrix((n, n), dtype=complex)
    for x in range(Nx):
        for y in range(Ny):
            for z in range(Nz):
                for (a, s, p) in PORTS:
                    e = [0, 0, 0]; e[a] = s
                    x2, y2, z2 = (x + e[0]) % Nx, (y + e[1]) % Ny, (z + e[2]) % Nz
                    Ssrc = nodes[(z2, x2 == x0 and y2 == y0)]
                    ph = np.exp(1j * Vprofile[z2]) if Vprofile is not None else 1.0
                    row = vid(x, y, z, (a, s, p))
                    src = PIDX[(a, -s, p)]
                    for j in range(NP):
                        c = Ssrc[src, j]
                        if c != 0:
                            U[row, vid(x2, y2, z2, PORTS[j])] += ph * c
    return csr_matrix(U)


def bloch_state(kz, Nx, Ny, Nz, phi, tau, gap_min=2.40, ref=None):
    """Etat de Bloch physique de la bande liee a k_z: psi_z = e^{i kz z} R(tau z) v."""
    x0, y0 = Nx // 2, Ny // 2
    U = bloch_map(kz, Nx, Ny, phi, tau, x0, y0)
    lam, W = np.linalg.eig(U)
    W = W / np.linalg.norm(W, axis=0)
    th = np.angle(lam)
    idxd = [(x0 * Ny + y0) * NP + q for q in range(NP)]
    loc = np.sum(np.abs(W[idxd, :]) ** 2, axis=0)
    if ref is None:
        cand = np.where((th > gap_min) & (th < np.pi - 1e-6))[0]
        c = int(cand[np.argmax(loc[cand])])
    else:
        c = int(np.argmax(np.abs(ref.conj() @ W)))
    v = W[:, c]
    psi = np.zeros((Nx, Ny, Nz, NP), complex)
    slab = v.reshape(Nx, Ny, NP)
    for z in range(Nz):
        R = pol_rotation(tau * z).astype(complex)
        psi[:, :, z, :] = np.exp(-1j * kz * z) * (slab @ R.T)
    return psi.reshape(-1), th[c], v


def make_packet(Nx, Ny, Nz, phi, tau, k0=1.5, sigk=0.15, nmodes=11):
    """Paquet gaussien assemble sur la bande liee, modes en phase.
    Retourne (psi, ks, amplitudes, omegas, vecteurs de tranche)."""
    n0 = int(round(k0 * Nz / (2 * np.pi)))
    ns = np.arange(n0 - nmodes // 2, n0 + nmodes // 2 + 1)
    ks = 2 * np.pi * ns / Nz
    A = np.exp(-((ks - k0) ** 2) / (2 * sigk ** 2))
    A = A / np.linalg.norm(A)
    psi = None; oms = []; slabs = []; ref = None
    for a, kz in zip(A, ks):
        s, om, v = bloch_state(kz, Nx, Ny, Nz, phi, tau, ref=ref)
        ref = v
        s = s / np.linalg.norm(s)
        psi = a * s if psi is None else psi + a * s
        oms.append(om); slabs.append(v)
    return psi / np.linalg.norm(psi), ks, A, np.array(oms), slabs


def z_moments(psi, Nx, Ny, Nz):
    """Densite le long de z, <z> et Var(z) (avec deroulement circulaire)."""
    P = np.abs(psi.reshape(Nx, Ny, Nz, NP)) ** 2
    rho = P.sum(axis=(0, 1, 3)); rho = rho / rho.sum()
    zs = np.arange(Nz)
    ph = np.exp(2j * np.pi * zs / Nz)
    zbar = np.angle(np.sum(rho * ph)) % (2 * np.pi) * Nz / (2 * np.pi)
    d = (zs - zbar + Nz / 2) % Nz - Nz / 2
    var = float(np.sum(rho * d ** 2))
    return rho, float(zbar), var
